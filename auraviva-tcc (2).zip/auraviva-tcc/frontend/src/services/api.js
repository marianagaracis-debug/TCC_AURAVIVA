// Comunicacao com o back-end (Spring Boot).
// O endereco da API vem de VITE_API_URL (arquivo frontend/.env). Padrao: http://localhost:8080
const API_URL = (import.meta.env.VITE_API_URL || "http://localhost:8080").replace(/\/+$/, "");

const CHAVE_PEDIDOS = "auraviva-pedidos";

export class ApiError extends Error {
  constructor(mensagem, status) {
    super(mensagem);
    this.status = status;
  }
}

async function requisicao(caminho, { metodo = "GET", corpo, formulario, cabecalhos = {} } = {}) {
  const opcoes = {
    method: metodo,
    credentials: "include",
    headers: { Accept: "application/json", ...cabecalhos },
  };

  if (formulario) {
    opcoes.body = new URLSearchParams(formulario);
    opcoes.headers["Content-Type"] = "application/x-www-form-urlencoded";
  } else if (corpo instanceof FormData) {
    opcoes.body = corpo;
    // Nao define Content-Type — browser define sozinho com boundary
  } else if (corpo !== undefined) {
    opcoes.body = JSON.stringify(corpo);
    opcoes.headers["Content-Type"] = "application/json";
  }

  let resposta;
  try {
    resposta = await fetch(`${API_URL}${caminho}`, opcoes);
  } catch {
    throw new ApiError("Não foi possível conectar ao servidor. Verifique se o back-end está em execução.", 0);
  }

  const texto = await resposta.text();
  let dados = null;
  try {
    dados = texto ? JSON.parse(texto) : null;
  } catch {
    dados = null;
  }

  if (!resposta.ok) {
    const campos = dados?.campos ? Object.values(dados.campos).join(" ") : "";
    const padrao = resposta.status === 401
      ? "Sessão expirada. Entre novamente."
      : resposta.status === 403
        ? "Você não tem permissão para esta ação."
        : "Não foi possível concluir a operação.";
    throw new ApiError(dados?.erro || dados?.error || campos || padrao, resposta.status);
  }

  return dados;
}

/* ================================================================
   Monta um FormData compatível com @RequestPart do Spring Boot.
   O campo "parte" é serializado como JSON (application/json blob).
   ================================================================ */
function montarFormMultipart(nomeParte, dados, arquivo) {
  const form = new FormData();
  form.append(nomeParte, new Blob([JSON.stringify(dados)], { type: "application/json" }));
  if (arquivo) form.append("file", arquivo);
  return form;
}

/* ================= Conta / login ================= */
export const api = {
  entrar: (email, senha) =>
    requisicao("/login", { metodo: "POST", formulario: { username: email, password: senha } }),
  sair: () => requisicao("/logout", { metodo: "POST" }),
  meuPerfil: () => requisicao("/usuarios/me"),
  atualizarPerfil: (campos) =>
    requisicao("/usuarios/me", { metodo: "PUT", corpo: campos }),
  alterarSenha: (senhaAtual, novaSenha) =>
    requisicao("/usuarios/me/alterar-senha", { metodo: "PUT", corpo: { senhaAtual, novaSenha } }),
  cadastrarCliente: (usuario) =>
    requisicao("/usuarios/create", { metodo: "POST", corpo: usuario }),
  cadastrarFuncionario: (usuario, codigo) =>
    requisicao("/usuarios/create-funcionario", {
      metodo: "POST",
      corpo: usuario,
      cabecalhos: { "X-Codigo-Funcionario": codigo || "" },
    }),
  listarUsuarios: () => requisicao("/usuarios/all"),

  /* ================= Recuperacao de senha ================= */
  solicitarCodigo: (email) =>
    requisicao(`/recuperar-senha/solicitar-codigo?email=${encodeURIComponent(email)}`, { metodo: "POST" }),
  validarCodigo: (email, codigo) =>
    requisicao(
      `/recuperar-senha/validar-codigo?email=${encodeURIComponent(email)}&codigo=${encodeURIComponent(codigo)}`,
      { metodo: "POST" },
    ),
  redefinirSenha: (email, codigo, novaSenha) =>
    requisicao("/recuperar-senha/redefinir-senha", {
      metodo: "POST",
      corpo: { email, codigo, novaSenha },
    }),

  /* ================= Catalogo ================= */
  listarProdutos: () => requisicao("/produtos/all"),
  listarProdutosPorEstacao: (estacao) => requisicao(`/produtos/estacao/${estacao}`),
  buscarProduto: (id) => requisicao(`/produtos/${id}`),
  criarProduto: (produto, arquivo) =>
    requisicao("/produtos", {
      metodo: "POST",
      corpo: montarFormMultipart("produto", produto, arquivo),
    }),
  editarProduto: (id, produto, arquivo) =>
    requisicao(`/produtos/${id}`, {
      metodo: "PUT",
      corpo: montarFormMultipart("produto", produto, arquivo),
    }),
  inativarProduto: (id) => requisicao(`/produtos/${id}/inativar`, { metodo: "PUT" }),
  ativarProduto:   (id) => requisicao(`/produtos/${id}/ativar`,   { metodo: "PUT" }),

  /* ================= Blog ================= */
  listarBlog: () => requisicao("/blogs/all"),
  buscarBlog: (id) => requisicao(`/blogs/${id}`),
  criarArtigo: (blog, arquivo) =>
    requisicao("/blogs", {
      metodo: "POST",
      corpo: montarFormMultipart("blog", blog, arquivo),
    }),
  editarArtigo: (id, blog, arquivo) =>
    requisicao(`/blogs/${id}`, {
      metodo: "PUT",
      corpo: montarFormMultipart("blog", blog, arquivo),
    }),
  inativarArtigo: (id) => requisicao(`/blogs/${id}/inativar`, { metodo: "PUT" }),

  /* ================= Fale conosco ================= */
  enviarMensagem: (mensagem) =>
    requisicao("/mensagens/enviar", { metodo: "POST", corpo: mensagem }),

  /* ================= Enderecos ================= */
  listarEnderecos: () => requisicao("/enderecos/me"),
  criarEndereco: (endereco) =>
    requisicao("/enderecos", { metodo: "POST", corpo: endereco }),
  editarEndereco: (id, endereco) =>
    requisicao(`/enderecos/${id}`, { metodo: "PUT", corpo: endereco }),
  excluirEndereco: (id) =>
    requisicao(`/enderecos/${id}`, { metodo: "DELETE" }),

  /* ================= Lista de desejos ================= */
  listarWishlist: () => requisicao("/wishlist"),
  adicionarWishlist: (idProduto) =>
    requisicao(`/wishlist/${idProduto}`, { metodo: "POST" }),
  removerWishlist: (idProduto) =>
    requisicao(`/wishlist/${idProduto}`, { metodo: "DELETE" }),

  /* ================= Newsletter ================= */
  inscreverNewsletter: (email) =>
    requisicao(`/newsletter/inscrever?email=${encodeURIComponent(email)}`, { metodo: "POST" }),

  /* ================= Pedidos ================= */
  criarPedido: (itens) =>
    requisicao("/vendas", { metodo: "POST", corpo: { itens } }),
  atualizarStatusPedido: (idVenda, statusVenda) =>
    requisicao(
      `/vendas/${idVenda}/status?statusVenda=${encodeURIComponent(statusVenda)}`,
      { metodo: "PUT" },
    ),
  atualizarRastreio: (idVenda, codigoRastreio, previsaoEntrega, enderecoEntrega) => {
    const params = new URLSearchParams();
    if (codigoRastreio  != null) params.set("codigoRastreio",  codigoRastreio);
    if (previsaoEntrega != null) params.set("previsaoEntrega", previsaoEntrega);
    if (enderecoEntrega != null) params.set("enderecoEntrega", enderecoEntrega);
    return requisicao(`/vendas/${idVenda}/rastreio?${params}`, { metodo: "PUT" });
  },
};

/* ================= Pedidos: conversao API <-> telas ================= */
const statusParaApi = {
  recebido:  "PENDENTE",
  preparacao: "PAGO",
  enviado:   "ENVIADO",
  entrega:   "ENVIADO",
  entregue:  "CONCLUIDO",
  cancelado: "CANCELADO",
};
const statusDaApi = {
  PENDENTE:  "recebido",
  PAGO:      "preparacao",
  ENVIADO:   "enviado",
  CONCLUIDO: "entregue",
  CANCELADO: "cancelado",
};

export const statusDoBanco = (statusTela) => statusParaApi[statusTela];
export const formatarIdPedido = (idVenda) => `AV-${String(idVenda).padStart(6, "0")}`;

const lerPedidosLocais = () => {
  try {
    const valor = JSON.parse(localStorage.getItem(CHAVE_PEDIDOS) || "[]");
    return Array.isArray(valor) ? valor : [];
  } catch {
    return [];
  }
};

export const converterPedido = (dto, locais = []) => {
  const local = locais.find((p) => p.idVenda === dto.id) || {};
  const status = statusParaApi[local.status] === dto.statusVenda
    ? local.status
    : statusDaApi[dto.statusVenda] || "recebido";

  return {
    ...local,
    id: formatarIdPedido(dto.id),
    idVenda: dto.id,
    criadoEm: dto.dataVenda,
    status,
    itens: dto.itens.map((item) => ({
      id: item.nome,
      nome: item.nome,
      preco: Number(item.precoUnitario),
      quantidade: item.quantidade,
      imagem: item.imagemUrl,
    })),
    subtotal: Number(dto.valorTotal) - Number(dto.frete),
    cliente: dto.cliente ? { nome: dto.cliente.nome, email: dto.cliente.email } : null,
    enderecoEntrega: dto.enderecoEntrega || local.enderecoEntrega || null,
    codigoRastreio:  dto.codigoRastreio  || local.codigoRastreio  || "",
    previsaoEntrega: dto.previsaoEntrega || local.previsaoEntrega || "",
    historico: Array.isArray(local.historico) && local.historico.length
      ? local.historico
      : [{ status, data: dto.dataVenda }],
  };
};

export async function sincronizarPedidos(equipe = false) {
  const dtos = await requisicao(equipe ? "/vendas/pedidos/todos" : "/vendas/pedidos");
  const locais = lerPedidosLocais();
  const pedidos = dtos.map((dto) => converterPedido(dto, locais));
  localStorage.setItem(CHAVE_PEDIDOS, JSON.stringify(pedidos));
  return pedidos;
}
